
import express from 'express';
// import {
//   isVerifiedToken,
//   requiredField,
//   validateField,
//   isAdmin
// } from '../middlewares';
import controller from 'PATH_TO_CONTROLLER/cms/booking';

const router = express.Router();

router.post('/', controller.createBooking);
router.get('/', controller.getAllBookings);
router.get('/:id', controller.getBooking);
router.delete('/:id', controller.deleteBooking);
router.patch('/:id', controller.updateBooking);
export default router;


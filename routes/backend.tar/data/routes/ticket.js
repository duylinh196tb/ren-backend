
import express from 'express';
// import {
//   isVerifiedToken,
//   requiredField,
//   validateField,
//   isAdmin
// } from '../middlewares';
import controller from 'PATH_TO_CONTROLLER/cms/ticket';

const router = express.Router();

router.post('/', controller.createTicket);
router.get('/', controller.getAllTickets);
router.get('/:id', controller.getTicket);
router.delete('/:id', controller.deleteTicket);
router.patch('/:id', controller.updateTicket);
export default router;


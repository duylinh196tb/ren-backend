
import express from 'express';
// import {
//   isVerifiedToken,
//   requiredField,
//   validateField,
//   isAdmin
// } from '../middlewares';
import controller from 'PATH_TO_CONTROLLER/cms/password';

const router = express.Router();

router.post('/', controller.createPassword);
router.get('/', controller.getAllPasswords);
router.get('/:id', controller.getPassword);
router.delete('/:id', controller.deletePassword);
router.patch('/:id', controller.updatePassword);
export default router;


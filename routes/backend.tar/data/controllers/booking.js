
import service from 'PATH_TO_FOLDER_SERVICE/service';
import Booking from 'PATH_TO_FOLDER_MODELS/models/booking';

const createBooking = async (req, res) => {
  const data = await Booking.create(req.body);
  res.json(service.response.success('Tạo Booking thành công!', data));
};

const getAllBookings = async (req, res) => {
  const data = await Booking.find().sort('-createdAt');
  res.json(
    service.response.success('Lấy danh sách Bookings thành công!', data)
  );
};

const getBooking = async (req, res) => {
  const data = await Booking.findById(req.params.id);
  if (data)
    return res.json(service.response.success('Lấy Booking thành công', data));
  res.json(service.response.objectNotFound('Khong tim thay Booking'));
};

const deleteBooking = async (req, res) => {
  const data = await Booking.findOneAndDelete({ _id: req.params.id });
  if (data)
    return res.json(
      service.response.success('Xoa Booking thanh cong', {
        _id: data._id
      })
    );
  res.json(service.response.objectNotFound('Không tìm thấy Booking'));
};

const updateBooking = async (req, res) => {
  const data = await Booking.findByIdAndUpdate(
    req.params.id,
    {
      $set: { ...req.body }
    },
    { new: true }
  );

  if (data)
    return res.json(service.response.success('Update thành công', data));
  res.json(service.response.objectNotFound('Không tìm thấy'));
};
export default {
  createBooking,
  getAllBookings,
  getBooking,
  deleteBooking,
  updateBooking
};



import service from 'PATH_TO_FOLDER_SERVICE/service';
import Password from 'PATH_TO_FOLDER_MODELS/models/password';

const createPassword = async (req, res) => {
  const data = await Password.create(req.body);
  res.json(service.response.success('Tạo Password thành công!', data));
};

const getAllPasswords = async (req, res) => {
  const data = await Password.find().sort('-createdAt');
  res.json(
    service.response.success('Lấy danh sách Passwords thành công!', data)
  );
};

const getPassword = async (req, res) => {
  const data = await Password.findById(req.params.id);
  if (data)
    return res.json(service.response.success('Lấy Password thành công', data));
  res.json(service.response.objectNotFound('Khong tim thay Password'));
};

const deletePassword = async (req, res) => {
  const data = await Password.findOneAndDelete({ _id: req.params.id });
  if (data)
    return res.json(
      service.response.success('Xoa Password thanh cong', {
        _id: data._id
      })
    );
  res.json(service.response.objectNotFound('Không tìm thấy Password'));
};

const updatePassword = async (req, res) => {
  const data = await Password.findByIdAndUpdate(
    req.params.id,
    {
      $set: { ...req.body }
    },
    { new: true }
  );

  if (data)
    return res.json(service.response.success('Update thành công', data));
  res.json(service.response.objectNotFound('Không tìm thấy'));
};
export default {
  createPassword,
  getAllPasswords,
  getPassword,
  deletePassword,
  updatePassword
};


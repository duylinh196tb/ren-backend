
import service from 'PATH_TO_FOLDER_SERVICE/service';
import Ticket from 'PATH_TO_FOLDER_MODELS/models/ticket';

const createTicket = async (req, res) => {
  const data = await Ticket.create(req.body);
  res.json(service.response.success('Tạo Ticket thành công!', data));
};

const getAllTickets = async (req, res) => {
  const data = await Ticket.find().sort('-createdAt');
  res.json(
    service.response.success('Lấy danh sách Tickets thành công!', data)
  );
};

const getTicket = async (req, res) => {
  const data = await Ticket.findById(req.params.id);
  if (data)
    return res.json(service.response.success('Lấy Ticket thành công', data));
  res.json(service.response.objectNotFound('Khong tim thay Ticket'));
};

const deleteTicket = async (req, res) => {
  const data = await Ticket.findOneAndDelete({ _id: req.params.id });
  if (data)
    return res.json(
      service.response.success('Xoa Ticket thanh cong', {
        _id: data._id
      })
    );
  res.json(service.response.objectNotFound('Không tìm thấy Ticket'));
};

const updateTicket = async (req, res) => {
  const data = await Ticket.findByIdAndUpdate(
    req.params.id,
    {
      $set: { ...req.body }
    },
    { new: true }
  );

  if (data)
    return res.json(service.response.success('Update thành công', data));
  res.json(service.response.objectNotFound('Không tìm thấy'));
};
export default {
  createTicket,
  getAllTickets,
  getTicket,
  deleteTicket,
  updateTicket
};


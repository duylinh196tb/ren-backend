
  import mongoose, { Schema } from 'mongoose';
  const PasswordSchema = new Schema(
    {},
    { timestamps: true }
  );
  
  export default mongoose.model(Password, PasswordSchema);
  
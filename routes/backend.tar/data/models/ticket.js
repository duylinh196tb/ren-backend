
  import mongoose, { Schema } from 'mongoose';
  const TicketSchema = new Schema(
    {},
    { timestamps: true }
  );
  
  export default mongoose.model(Ticket, TicketSchema);
  

  import mongoose, { Schema } from 'mongoose';
  const BookingSchema = new Schema(
    {},
    { timestamps: true }
  );
  
  export default mongoose.model(Booking, BookingSchema);
  
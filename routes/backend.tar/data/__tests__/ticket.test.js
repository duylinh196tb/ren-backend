
import {
  testGet,
  testPost,
  testDelete,
  testUpdate,
  testOther,
  hostApp
} from "PATH_TO_SEED/helperTest";
import { admin, tickets } from "PATH_TO_SEED/seed";
import Ticket from "PATH_TO_MODEL_TEST/models/ticket";

const initalData = {
  dataSeed: tickets,
  model: Ticket,
  token: "access_token "+ admin.token,
  url: "/cms/tickets"
};

describe("### TICKET", () => {
  const data = {
    thumbnail: "question 1",
    detail: "3",
    deteAndTime: "thu 6 ngay 13"
  };

  testGet(initalData);
  testPost(initalData, data);
  testDelete(initalData);
  testUpdate(initalData, data);
});

